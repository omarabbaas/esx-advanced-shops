-- Initialize variables
local CurrentAction = nil
local CurrentShop = nil
local CurrentShopId = nil
local CurrentShopData = nil
local CurrentZoneType = nil
local ShopMarkers = {}
local TargetPoints = {}

-- Player loaded event
RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
    RefreshBlips()
    InitializeShops()
end)

-- Initialize shops
function InitializeShops()
    -- Get all shops data
    ESX.TriggerServerCallback('esx_advanced_shops:getAllShops', function(shops)
        -- Set up shop markers or target points
        for i = 1, #shops do
            local shop = shops[i]
            local coords = vector3(shop.coords.x, shop.coords.y, shop.coords.z)
            
            if Config.UseOxTarget then
                -- Create a target point for ox_target
                if not TargetPoints[shop.id] then
                    TargetPoints[shop.id] = exports.ox_target:addSphereZone({
                        coords = coords,
                        radius = 2.0,
                        options = {
                            {
                                name = 'shop_interact_' .. shop.id,
                                icon = 'fas fa-shopping-basket',
                                label = TranslateCap('press_to_open'),
                                canInteract = function()
                                    return shop.open and not isRobbingShop
                                end,
                                onSelect = function()
                                    OpenShopMenu(shop.id, shop)
                                end
                            }
                        }
                    })
                    
                    -- If this shop can be robbed, add robbery option
                    exports.ox_target:addSphereZone({
                        coords = coords,
                        radius = 2.0,
                        options = {
                            {
                                name = 'shop_rob_' .. shop.id,
                                icon = 'fas fa-mask',
                                label = TranslateCap('press_to_rob'),
                                canInteract = function()
                                    return not isRobbingShop and shop.open and not IsPedInAnyVehicle(PlayerPedId(), true)
                                end,
                                onSelect = function()
                                    TriggerEvent('esx_advanced_shops:startRobbery', shop.id, shop)
                                end
                            }
                        }
                    })
                    
                    -- If player owns this shop, add management option
                    if shop.owner == PlayerData.identifier then
                        exports.ox_target:addSphereZone({
                            coords = coords,
                            radius = 2.0,
                            options = {
                                {
                                    name = 'shop_manage_' .. shop.id,
                                    icon = 'fas fa-cogs',
                                    label = TranslateCap('press_to_manage'),
                                    canInteract = function()
                                        return shop.owner == PlayerData.identifier and not isRobbingShop
                                    end,
                                    onSelect = function()
                                        OpenManagementMenu(shop.id, shop)
                                    end
                                }
                            }
                        })
                    end
                end
            else
                -- Add marker to list for drawing
                ShopMarkers[shop.id] = {
                    coords = coords,
                    type = 'shop',
                    shopId = shop.id,
                    shop = shop
                }
            end
        end
        
        -- Also create the shop center marker/target
        local centerCoords = Config.ShopsCenter.coords
        
        if Config.UseOxTarget then
            exports.ox_target:addSphereZone({
                coords = centerCoords,
                radius = 2.0,
                options = {
                    {
                        name = 'shop_center',
                        icon = 'fas fa-store',
                        label = TranslateCap('shop_center'),
                        canInteract = function()
                            return not isRobbingShop
                        end,
                        onSelect = function()
                            OpenShopCenter()
                        end
                    }
                }
            })
        else
            ShopMarkers['center'] = {
                coords = centerCoords,
                type = 'center',
                shopId = 'center'
            }
        end
    end)
end

-- Main thread for handling markers if ox_target is not used
Citizen.CreateThread(function()
    if Config.UseOxTarget then return end
    
    while true do
        Citizen.Wait(0)
        local playerCoords = GetEntityCoords(PlayerPedId())
        local isInMarker = false
        local currentZone = nil
        local currentZoneType = nil
        local currentShopData = nil
        
        -- Draw markers and check if player is in any marker
        for id, marker in pairs(ShopMarkers) do
            local distance = #(playerCoords - marker.coords)
            
            if distance < 10.0 then
                DrawMarker(1, marker.coords.x, marker.coords.y, marker.coords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.5, 1.5, 0.5, 50, 205, 50, 100, false, true, 2, false, nil, nil, false)
                
                if distance < 1.5 then
                    isInMarker = true
                    currentZone = marker.shopId
                    currentZoneType = marker.type
                    currentShopData = marker.shop
                end
            end
        end
        
        -- Handle entering/exiting markers
        if isInMarker and not hasAlreadyEnteredMarker then
            hasAlreadyEnteredMarker = true
            TriggerEvent('esx_advanced_shops:hasEnteredMarker', currentZone, currentZoneType, currentShopData)
        end
        
        if not isInMarker and hasAlreadyEnteredMarker then
            hasAlreadyEnteredMarker = false
            TriggerEvent('esx_advanced_shops:hasExitedMarker')
        end
    end
end)

-- Thread for displaying help text and handling key presses
Citizen.CreateThread(function()
    if Config.UseOxTarget then return end
    
    while true do
        Citizen.Wait(0)
        
        if CurrentAction ~= nil then
            ESX.ShowHelpNotification(CurrentActionMsg)
            
            if IsControlJustReleased(0, Keys['E']) then
                if CurrentAction == 'shop_menu' then
                    if CurrentShopData and CurrentShopData.open then
                        OpenShopMenu(CurrentShopId, CurrentShopData)
                    else
                        ShowNotification(TranslateCap('shop_closed'))
                    end
                elseif CurrentAction == 'shop_management' then
                    OpenManagementMenu(CurrentShopId, CurrentShopData)
                elseif CurrentAction == 'shop_center' then
                    OpenShopCenter()
                elseif CurrentAction == 'shop_robbery' then
                    if CurrentShopData and CurrentShopData.open then
                        TriggerEvent('esx_advanced_shops:startRobbery', CurrentShopId, CurrentShopData)
                    else
                        ShowNotification(TranslateCap('shop_closed'))
                    end
                end
                
                CurrentAction = nil
            end
        end
    end
end)

-- Enter marker event handler
RegisterNetEvent('esx_advanced_shops:hasEnteredMarker')
AddEventHandler('esx_advanced_shops:hasEnteredMarker', function(zone, zoneType, shopData)
    if zoneType == 'center' then
        CurrentAction = 'shop_center'
        CurrentActionMsg = TranslateCap('press_to_open')
    elseif zoneType == 'shop' then
        CurrentShopId = zone
        CurrentShopData = shopData
        
        if shopData.owner == PlayerData.identifier then
            CurrentAction = 'shop_management'
            CurrentActionMsg = TranslateCap('press_to_manage')
        else
            CurrentAction = 'shop_menu'
            CurrentActionMsg = TranslateCap('press_to_open')
        end
    end
end)

-- Exit marker event handler
RegisterNetEvent('esx_advanced_shops:hasExitedMarker')
AddEventHandler('esx_advanced_shops:hasExitedMarker', function()
    CurrentAction = nil
    CurrentShopId = nil
    CurrentShopData = nil
end)

-- Shop items updated event handler
RegisterNetEvent('esx_advanced_shops:shopStockUpdated')
AddEventHandler('esx_advanced_shops:shopStockUpdated', function(shopId)
    if CurrentShopId == shopId and isShopOpen then
        ESX.TriggerServerCallback('esx_advanced_shops:getShopItems', function(items)
            if items then
                RefreshShopMenu(items)
            else
                ESX.UI.Menu.CloseAll()
                isShopOpen = false
            end
        end, shopId)
    end
end)

-- Shop ownership changed event handler
RegisterNetEvent('esx_advanced_shops:ownershipChanged')
AddEventHandler('esx_advanced_shops:ownershipChanged', function()
    -- Refresh blips when shop ownership changes
    RefreshBlips()
    InitializeShops()
end)

-- Shop open/close status changed event handler
RegisterNetEvent('esx_advanced_shops:shopStatusChanged')
AddEventHandler('esx_advanced_shops:shopStatusChanged', function(shopId, isOpen)
    -- Update local shop data
    if CurrentShopId == shopId and CurrentShopData then
        CurrentShopData.open = isOpen
    end
    
    -- Refresh shops
    InitializeShops()
end)